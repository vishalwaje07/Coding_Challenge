package com.example.quizapp.service;

public class QuestionService {

}
