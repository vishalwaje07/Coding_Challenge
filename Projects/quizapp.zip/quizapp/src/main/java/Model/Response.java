package Model;

public class Response {

}
